﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;
using UnityEngine.SceneManagement;

public class SphereController : MonoBehaviour
{
    public float speed;
    private Rigidbody rb;
    private int score;
    public Text scoreText;
    public Text winText;
    private float totalTime;
    private bool isCompleted;

    void Start()
    {
        rb = GetComponent<Rigidbody>();
        ResetVariables();        
    }
    void ResetVariables()
    {
        score = 0;
        scoreText.text = "Score: " + score.ToString();
        SetScoreText();
        winText.text = "";
        totalTime = 0.0f;
        isCompleted = false;
    }

    void Update()
    {
        totalTime += Time.deltaTime;

        if (Input.GetKey(KeyCode.Escape))
        {
            Application.Quit();
        }
        if (Input.GetKey(KeyCode.R))
        {
            ResetVariables();
            SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
        }
    }
    void FixedUpdate()
    {
        if (!isCompleted)
        {
            float movX = Input.GetAxis("Horizontal");
            float movY = Input.GetAxis("Vertical");

            Vector3 movement = new Vector3(movX, 0.0f, movY);
            rb.AddForce(movement * speed);
        }
    }
    void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.CompareTag("Coin"))
        {
            Debug.Log("coin");
            other.gameObject.SetActive(false);
            score ++;
            SetScoreText();
        }

    }

    void OnCollisionEnter(Collision other)
    {
        if (other.gameObject.CompareTag("Enemy"))
        {
            if (isCompleted == false){
                winText.text = "You lost! Press R to restart, or ESC to quit.\nMovement disabled.";
                isCompleted = true;
            }            
        }
    }

        void SetScoreText()
    {
        scoreText.text = "Items collected: " + score.ToString();
        if (score == 9)
        {
            winText.text = "You Win!! It took you " + totalTime+ " s."+"\nMovement disabled. You can press ESC to quit.\n Game made by Joan Garcia (NIA: 205331)";
            isCompleted = true;
        }
    }



    // https://learn.unity.com/tutorial/environment-and-player?language=en&projectId=5c51479fedbc2a001fd5bb9f#5c7f8529edbc2a002053b786
    // https://unity.github.com/
    // Powerpoint "P1", homework: hay que hacer"Roll a ball homework"
}
